﻿using System.Collections.Generic;
using System.Diagnostics;
namespace Tree
{
    internal class Program
    {

        public class Node
        {
            public string Name { get; set; }
            public bool Searched { get; set; }
            public Stack<Node> Children { get; set; } = new Stack<Node>();

            public Node(string name)
            {
                Name = name;
            }

            public int CountDesendantsRecursion()
            {
                try
                {
                    return Desendants();
                }
                finally
                {
                    Searched = false;
                    ResetSearched();
                }
            }
            public int CountDesendantsNoRecursion()
            {
                try
                {
                    return DesendantsNoRecursion();
                }
                finally
                {
                    Searched = false;
                    ResetSearched();
                }
            }

            private int DesendantsNoRecursion()
            {
                int count = 0;
                Queue<Node> queue = new Queue<Node>();
                queue.Enqueue(this);
                while(queue.Count != 0)
                {
                    Node node = queue.Dequeue();
                    foreach(Node child in node.Children)
                    {
                        if (!child.Searched)
                        {
                            count++;
                            child.Searched = true;
                            queue.Enqueue(child);
                        }
                    }
                }
                return count;
            }

            private void ResetSearched()
            {
                foreach (var child in Children)
                {
                    if (child.Searched)
                    {
                        child.ResetSearched();
                    }
                }
                Searched = false;
            }

            private int Desendants()
            {
                if (!Searched)
                {
                    Searched = true;
                    int count = 0;
                    foreach (var node in Children)
                    {
                        count += node.Desendants();
                    }
                    return count + Children.Count;
                }
                return 0;
            }

            public override string ToString()
            {
                return Name;
            }
        }
        static void Main(string[] args)
        {
            Node A = new Node("A");
            Node B = new Node("B");
            Node C = new Node("C");
            Node D = new Node("D");
            Node E = new Node("E");
            Node F = new Node("F");

            A.Children.Push(B);
            B.Children.Push(D);
            B.Children.Push(E);
            A.Children.Push(C);
            C.Children.Push(F);
            F.Children.Push(A);

            // Assuming a tree and A is the only one we have
            var total = A.CountDesendantsRecursion();
            var noRecursionTotal = A.CountDesendantsNoRecursion();

            Debug.Assert(total == 5);
            Debug.Assert(noRecursionTotal == 5);
        }
    }
}
